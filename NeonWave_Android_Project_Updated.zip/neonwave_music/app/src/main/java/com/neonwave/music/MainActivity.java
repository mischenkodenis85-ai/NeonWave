package com.neonwave.music;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.content.ContentUris;
import android.database.Cursor;
import android.provider.MediaStore;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    int bg = Color.rgb(8,10,18), panel = Color.rgb(19,22,36), cyan = Color.rgb(0,245,212), pink = Color.rgb(255,60,172), white = Color.WHITE, muted = Color.rgb(155,164,184);
    LinearLayout root, list; EditText search; TextView status, nowPlaying; ArrayList<Song> songs = new ArrayList<>(); ArrayList<Song> shown = new ArrayList<>();
    android.media.MediaPlayer player; int current = -1; boolean playing = false;
    static class Song { long id; String title, artist; Uri uri; Song(long i,String t,String a,Uri u){id=i;title=t;artist=a;uri=u;} }
    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); requestAudioPermission(); }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    GradientDrawable bgShape(int color,int stroke){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16)); if(stroke!=0)d.setStroke(dp(1),stroke); return d; }
    void build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(22),dp(18),dp(20)); root.setBackgroundColor(bg); scroll.addView(root); setContentView(scroll);
        TextView logo=text("NEON",28,cyan,true); TextView logo2=text("WAVE  ♪",28,pink,true); LinearLayout brand=new LinearLayout(this); brand.setOrientation(0); brand.addView(logo); brand.addView(logo2); root.addView(brand);
        TextView subtitle=text("ТВОЯ МУЗИКА. НАВІТЬ ОФЛАЙН.",11,muted,true); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(4); root.addView(subtitle,sp);
        search=new EditText(this); search.setSingleLine(true); search.setHint("Знайти пісню або виконавця…"); search.setHintTextColor(muted); search.setTextColor(white); search.setPadding(dp(14),0,dp(14),0); search.setBackground(bgShape(panel,cyan)); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(52)); ep.topMargin=dp(22); root.addView(search,ep);
        Button find=button("ПОШУК МУЗИКИ В ІНТЕРНЕТІ",cyan,bg); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(48)); fp.topMargin=dp(10); root.addView(find,fp); find.setOnClickListener(v->{String q=search.getText().toString().trim(); if(q.isEmpty()){toast("Спочатку введи назву пісні або виконавця");return;} Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(q))); startActivity(i);});
        search.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int start,int count,int after){} public void onTextChanged(CharSequence s,int start,int before,int count){filterLocalSongs(s.toString());} public void afterTextChanged(android.text.Editable e){} });
        TextView section=text("МОЯ МУЗИКА  ✦",18,white,true); LinearLayout.LayoutParams sec=new LinearLayout.LayoutParams(-1,-2); sec.topMargin=dp(26); root.addView(section,sec);
        TextView hint=text("Пісні, збережені на телефоні, працюють без інтернету.",12,muted,false); root.addView(hint);
        Button refresh=button("ОНОВИТИ БІБЛІОТЕКУ",pink,bg); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(44)); rp.topMargin=dp(12); root.addView(refresh,rp); refresh.setOnClickListener(v->loadSongs());
        status=text("Дозволь доступ до аудіофайлів, щоб знайти музику на телефоні.",12,muted,false); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2); stp.topMargin=dp(12); root.addView(status,stp);
        list=new LinearLayout(this); list.setOrientation(1); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(12); root.addView(list,lp);
        LinearLayout playerCard=new LinearLayout(this); playerCard.setOrientation(1); playerCard.setPadding(dp(14),dp(12),dp(14),dp(12)); playerCard.setBackground(bgShape(panel,pink)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(18); root.addView(playerCard,cp);
        nowPlaying=text("Зараз нічого не грає",14,white,true); playerCard.addView(nowPlaying);
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL); playerCard.addView(controls);
        Button play=button("▶ / ❚❚  Відтворити / Пауза",cyan,bg); controls.addView(play,new LinearLayout.LayoutParams(0,dp(44),1)); play.setOnClickListener(v->toggle());
        Button stop=button("■",pink,bg); LinearLayout.LayoutParams stopP=new LinearLayout.LayoutParams(dp(55),dp(44)); stopP.leftMargin=dp(8); controls.addView(stop,stopP); stop.setOnClickListener(v->stopPlayer());
        TextView footer=text("Порада: завантажуй музику лише з джерел, що дозволяють збереження.",10,muted,false); LinearLayout.LayoutParams foot=new LinearLayout.LayoutParams(-1,-2); foot.topMargin=dp(18); root.addView(footer,foot);
    }
    Button button(String label,int foreground,int background){Button b=new Button(this);b.setText(label);b.setTextColor(foreground);b.setAllCaps(false);b.setTextSize(12);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bgShape(background,foreground));return b;}
    void requestAudioPermission(){
        String perm=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(perm)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{perm},42); else loadSongs();
    }
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==42){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadSongs();else status.setText("Без дозволу не можу показати локальні аудіофайли. Можеш дозволити доступ у налаштуваннях.");}}
    void loadSongs(){
        songs.clear(); list.removeAllViews();
        Uri collection=Build.VERSION.SDK_INT>=29?MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL):MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST};
        String selection=MediaStore.Audio.Media.IS_MUSIC+" != 0";
        try(Cursor c=getContentResolver().query(collection,projection,selection,null,MediaStore.Audio.Media.TITLE+" ASC")){
            if(c!=null)while(c.moveToNext()){long id=c.getLong(0);String title=c.getString(1);String artist=c.getString(2);Uri uri=ContentUris.withAppendedId(collection,id);songs.add(new Song(id,title==null?"Без назви":title,artist==null?"Невідомий виконавець":artist,uri));}
        }catch(Exception e){status.setText("Не вдалося прочитати аудіобібліотеку.");}
        status.setText("Знайдено пісень: "+songs.size()+" · Вибери трек для офлайн-прослуховування.");
        render(songs);
    }
    void filterLocalSongs(String query){
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        ArrayList<Song> filtered=new ArrayList<>();
        for(Song song:songs){
            if(song.title.toLowerCase(Locale.ROOT).contains(q)||song.artist.toLowerCase(Locale.ROOT).contains(q)) filtered.add(song);
        }
        if(status!=null) status.setText(q.isEmpty()?"Знайдено пісень: "+songs.size()+" · Вибери трек для офлайн-прослуховування.":"Збігів у твоїй бібліотеці: "+filtered.size()+" · Для пошуку в інтернеті натисни кнопку вище.");
        render(filtered);
    }
    void render(ArrayList<Song> data){
        list.removeAllViews();
        if(data.isEmpty()){TextView empty=text("Тут поки немає музики. Збережи аудіофайли на телефон і натисни «Оновити бібліотеку».",13,muted,false);empty.setPadding(dp(8),dp(12),dp(8),dp(12));list.addView(empty);return;}
        for(Song s:data){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(8),dp(8));row.setBackground(bgShape(panel,Color.rgb(43,48,70)));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.bottomMargin=dp(8);list.addView(row,rlp);
            LinearLayout names=new LinearLayout(this);names.setOrientation(1);row.addView(names,new LinearLayout.LayoutParams(0,-2,1));
            TextView title=text(s.title,14,white,true);TextView artist=text(s.artist,11,muted,false);names.addView(title);names.addView(artist);
            Button play=button("▶",cyan,bg);row.addView(play,new LinearLayout.LayoutParams(dp(48),dp(42)));play.setOnClickListener(v->playSong(s));
        }
    }
    void playSong(Song s){
        stopPlayer();try{player=new android.media.MediaPlayer();player.setDataSource(this,s.uri);player.setOnPreparedListener(mp->{mp.start();playing=true;nowPlaying.setText("▶ "+s.title+" — "+s.artist);});player.setOnCompletionListener(mp->{playing=false;nowPlaying.setText("✓ Завершено: "+s.title);});player.setOnErrorListener((mp,what,extra)->{toast("Не вдалося відтворити цей файл");stopPlayer();return true;});player.prepareAsync();nowPlaying.setText("Завантаження: "+s.title);}catch(Exception e){toast("Не вдалося відкрити файл");stopPlayer();}
    }
    void toggle(){if(player==null){toast("Спочатку вибери пісню зі списку");return;}try{if(player.isPlaying()){player.pause();playing=false;nowPlaying.setText("Ⅱ Пауза");}else{player.start();playing=true;nowPlaying.setText("▶ Відтворення");}}catch(Exception e){toast("Не вдалося керувати відтворенням");}}
    void stopPlayer(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}playing=false;nowPlaying.setText("Зараз нічого не грає");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){stopPlayer();super.onDestroy();}
}
